﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programming_project_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            birthdayDtp.Value = DateTime.Now;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void colorCombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            colorCombobox.SelectionLength = 0;
        }

        private void luckyBtn_Click(object sender, EventArgs e)
        {
            Form2 myMessageForm = new Form2();
            myMessageForm.ShowDialog();
            
            
        } 
    }
}
