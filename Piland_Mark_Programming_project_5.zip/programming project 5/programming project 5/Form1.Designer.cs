﻿namespace programming_project_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.birthdayDtp = new System.Windows.Forms.DateTimePicker();
            this.colorCombobox = new System.Windows.Forms.ComboBox();
            this.luckyBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Birthday:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(64, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Favorite Color:";
            // 
            // birthdayDtp
            // 
            this.birthdayDtp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.birthdayDtp.Location = new System.Drawing.Point(79, 56);
            this.birthdayDtp.Name = "birthdayDtp";
            this.birthdayDtp.Size = new System.Drawing.Size(109, 20);
            this.birthdayDtp.TabIndex = 4;
            this.birthdayDtp.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // colorCombobox
            // 
            this.colorCombobox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.colorCombobox.FormattingEnabled = true;
            this.colorCombobox.Items.AddRange(new object[] {
            "Red",
            "Blue",
            "Green",
            "Yellow",
            "Orange",
            "Purple",
            "Black",
            "White"});
            this.colorCombobox.Location = new System.Drawing.Point(67, 147);
            this.colorCombobox.Name = "colorCombobox";
            this.colorCombobox.Size = new System.Drawing.Size(121, 21);
            this.colorCombobox.TabIndex = 5;
            this.colorCombobox.SelectedIndexChanged += new System.EventHandler(this.colorCombobox_SelectedIndexChanged);
            // 
            // luckyBtn
            // 
            this.luckyBtn.Location = new System.Drawing.Point(61, 205);
            this.luckyBtn.Name = "luckyBtn";
            this.luckyBtn.Size = new System.Drawing.Size(150, 44);
            this.luckyBtn.TabIndex = 6;
            this.luckyBtn.Text = "Get Lucky Number";
            this.luckyBtn.UseVisualStyleBackColor = true;
            this.luckyBtn.Click += new System.EventHandler(this.luckyBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.luckyBtn);
            this.Controls.Add(this.colorCombobox);
            this.Controls.Add(this.birthdayDtp);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Lucky Number";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker birthdayDtp;
        private System.Windows.Forms.ComboBox colorCombobox;
        private System.Windows.Forms.Button luckyBtn;
    }
}

