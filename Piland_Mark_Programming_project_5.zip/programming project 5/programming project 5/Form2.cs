﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace programming_project_5
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

     

        private void Form2_Load(object sender, EventArgs e)
        {
            Random rndm = new Random();
            int number = rndm.Next(1, 999);
            luckynumberTextbox.Text = number.ToString();
        }
    }
}
