﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace milestone4
{
    public partial class Form4 : Form
    {
        public delegate void BirdHabitatUpdateHandler(object sender,
          BirdHabitatUpdateEventArgs e);


        public event BirdHabitatUpdateHandler BirdHabitatUpdated;

        public Form4(List<BirdData> bd)
        {
            InitializeComponent();
            foreach (BirdData bird in bd)
                listBox2.Items.Add(bird.Habitat);
        }

        private void btnFind2_Click(object sender, EventArgs e)
        {
            BirdHabitatUpdateEventArgs args = new BirdHabitatUpdateEventArgs(listBox2.SelectedItem.ToString());

            BirdHabitatUpdated(this, args);
        }
    }
    public class BirdHabitatUpdateEventArgs : System.EventArgs
    {

        private string mHabitat;


        public BirdHabitatUpdateEventArgs(string sHabitat)
        {
            this.mHabitat = sHabitat;
        }


        public string Habitat
        {
            get
            {
                return mHabitat;
            }
        }
    }
}
